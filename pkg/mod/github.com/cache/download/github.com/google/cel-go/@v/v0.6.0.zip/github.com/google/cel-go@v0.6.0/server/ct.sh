#!/bin/bash
exec "$@"
