### Welcome to the CEL Codelab!
---

Find the codelab instructions [here](https://codelabs.developers.google.com/codelabs/cel-go/#0). It requires some knowledge of GoLang and Protobuf.

If you get stuck, check out the [solutions](https://github.com/google/cel-go/blob/master/codelab/solution/codelab.go).

If you find a bug or want to make an improvement, PRs and issues are welcome. Please follow the [contributing guidelines](https://github.com/google/cel-go/blob/master/CONTRIBUTING.md).
