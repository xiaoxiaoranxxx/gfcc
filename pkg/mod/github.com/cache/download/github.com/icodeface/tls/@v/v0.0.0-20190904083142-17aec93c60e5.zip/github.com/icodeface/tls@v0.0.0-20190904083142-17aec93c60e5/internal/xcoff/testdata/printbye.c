#include <stdio.h>

void printbye(){
	printf("Goodbye\n");
}
