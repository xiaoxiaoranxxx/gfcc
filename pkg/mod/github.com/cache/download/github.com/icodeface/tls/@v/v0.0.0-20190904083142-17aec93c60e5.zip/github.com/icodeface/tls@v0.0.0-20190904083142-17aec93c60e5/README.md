# tls

A copy of golang official [crypto/tls (1.12.9)](https://github.com/golang/go/tree/06472b99cdf59f00049f3cd8c9e05ba283cb2c56/src/crypto/tls) implementation with some minor changes.

**Do not use in production environment before you know all the changes I have made**
